import { useState } from 'react';
import { fetchMeMovies } from '../utils/movieService';
import Movie from './Movie';

const Movies = () => {
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const movies = await fetchMeMovies();
      setData(movies);
    } catch (error) {
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  const handleEvent = () => {
    fetchData();
  };

  return (
    <div>
      <h2>Movies</h2>
      {error ? <p>{error.message}</p> : null}
      {loading ? <p>Laster ...</p> : null}
      {data.map((movie) => (
        <Movie key={movie.title} title={movie.title} actor={movie.actor} />
      ))}
      <button onClick={handleEvent} type="button">
        Click me
      </button>
    </div>
  );
};

export default Movies;