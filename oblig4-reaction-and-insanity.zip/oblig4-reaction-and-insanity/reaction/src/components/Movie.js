const Movie = ({ title, actor }) => (
    <section>
      <h2>Title: {title}</h2>
      <p>Actor: {actor}</p>
    </section>
  );
  
  export default Movie;
