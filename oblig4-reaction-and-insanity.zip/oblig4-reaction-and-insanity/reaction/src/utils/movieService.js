import client from './client';

const movieFields = `
_id,
title,
'actor': actor->name
`;

export const fetchMeMovies = async () => {
  const data = await client.fetch(`*[_type == "movie"]{${movieFields}}`);
  return data;
};
