Her kan du legge til hjelpefunksjoner og "services" for å hente data fra f.eks Sanity
